from django.contrib import admin

from .models import UserStatus

admin.site.register(UserStatus)
